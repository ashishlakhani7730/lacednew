

<!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
<!--[if lte IE 8 ]>
<html lang="en" class="ie ie8">
   <![endif]-->
   <!--[if IE 9 ]>
   <html lang="en" class="ie">
      <![endif]-->
      <head>
         <meta charset="utf-8">
         <meta http-equiv="X-UA-Compatible" content="IE=edge">
         <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
         <!--[if IE]>
         <meta http-equiv="X-UA-Compatible" content="IE=edge" />
         <![endif]-->
         <title> V9 &#8211; AUCTION THEME</title>
         <style></style><link rel='stylesheet' id='premiumpress-elementor-css-css'  href='https://at9.premiummod.com/wp-content/themes/AT9/framework/elementor/css/elementor.css?ver=5.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='https://at9.premiummod.com/wp-includes/css/dist/block-library/style.min.css?ver=5.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='framework1-css'  href='https://at9.premiummod.com/wp-content/themes/AT9/framework/css/backup_css/css.bootstrap.css?ver=9.4.0' type='text/css' media='' />
<link rel='stylesheet' id='framework2-css'  href='https://at9.premiummod.com/wp-content/themes/AT9/framework/css/backup_css/css.plugins.css?ver=9.4.0' type='text/css' media='' />
<link rel='stylesheet' id='framework3-css'  href='https://at9.premiummod.com/wp-content/themes/AT9/framework/css/backup_css/css.styles.css?ver=9.4.0' type='text/css' media='' />
<link rel='stylesheet' id='framework4-css'  href='https://at9.premiummod.com/wp-content/themes/AT9/framework/css/backup_css/css.menu.css?ver=9.4.0' type='text/css' media='' />
<link rel='stylesheet' id='framework5-css'  href='https://at9.premiummod.com/wp-content/themes/AT9/framework/css/backup_css/css.shortcodes.css?ver=9.4.0' type='text/css' media='' />
<link rel='stylesheet' id='framework6-css'  href='https://at9.premiummod.com/wp-content/themes/AT9/framework/css/backup_css/css.widgets.css?ver=9.4.0' type='text/css' media='' />
<link rel='stylesheet' id='framework7-css'  href='https://at9.premiummod.com/wp-content/themes/AT9/framework/css/backup_css/css.search.css?ver=9.4.0' type='text/css' media='' />
<link rel='stylesheet' id='framework8-css'  href='https://at9.premiummod.com/wp-content/themes/AT9/framework/css/backup_css/css.account.css?ver=9.4.0' type='text/css' media='' />
<link rel='stylesheet' id='framework9-css'  href='https://at9.premiummod.com/wp-content/themes/AT9/framework/css/backup_css/css.responsive.css?ver=9.4.0' type='text/css' media='' />
<link rel='stylesheet' id='framework10-css'  href='https://at9.premiummod.com/wp-content/themes/AT9/framework/css/backup_css/css.googlefonts.css?ver=9.4.0' type='text/css' media='' />
<link rel='stylesheet' id='framework11-css'  href='https://at9.premiummod.com/wp-content/themes/AT9/_auction/css.global.css?ver=9.4.0' type='text/css' media='' />
<link rel='stylesheet' id='framework12-css'  href='https://at9.premiummod.com/wp-content/themes/AT9/_auction/template/style.css?ver=9.4.0' type='text/css' media='' />
<script src="https://at9.premiummod.com/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp"></script>
<script src="https://at9.premiummod.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1"></script>
<link rel='https://api.w.org/' href='https://at9.premiummod.com/wp-json/' />
    <style>
.bg-primary, .ppt-home-block-1 .owl-slider .owl-buttons div, .listing-small .wrap .btn-quickview, footer .socials .social, .section-title::before, .owl-buttons div { background:#dc3545 !important; } .btn-primary, .btn-primary:hover { color: #fff; background-color: #dc3545 !important; border-color: #dc3545 !important; } 
.hero0::after { background:#dc3545f2 !important; } #widget-single-hero .overlay { background:#dc3545f2 !important; } .text-primary { color:#dc3545 !important; }
</style>
	 
         <!--[if lt IE 9]>
         <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
         <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
         <![endif]-->          
      </head>
      <body class="ppt_login demomode theme-at" >      
      
      	       
      
         <div id="ajax_page_top"></div>
         <div id="page">
        
         <header><nav class="elementor_header elementor_topmenu header-top1 py-3 style2 d-none d-sm-block bg-dark">
   <div class="container">
      <div class="row">
         <div class="col-12 col-lg-6 px-0">                
            <div class="menu-top-menu-container"><ul id="menu-top-menu" class="clearfix mb-0 seperator"><li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://at9.premiummod.com/faq/" class="txt"><span>FAQ</span></a></li><li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://at9.premiummod.com/about-us/" class="txt"><span>About Us</span></a></li><li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://at9.premiummod.com/testimonials/" class="txt"><span>Testimonials</span></a></li><li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://at9.premiummod.com/privacy/" class="txt"><span>Privacy</span></a></li><li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://at9.premiummod.com/advertising/" class="txt"><span>Advertising</span></a></li></ul></div>         </div>
         <div class="col-lg-6 d-none d-lg-block pr-0">
            <ul class="float-right clearfix mb-0">
                                       
               <li class="px-3">
                                    Welcome, Guest ( <a href="https://at9.premiummod.com/wp-login.php"><u>Login</u></a> | 
                  <a href="https://at9.premiummod.com/wp-login.php?action=register"><u>Register</u></a> )
                                     
               </li>
            </ul>
         </div>
      </div>
   </div>
</nav><div class="elementor_header elementor_logo pptv9-header border-bottom border-top bg-white  viewport-lg  no-sticky">
   <div class="container py-lg-3">
      <div class="pptv9-header-container">
         <div class="logo" data-mobile-logo="https://at9.premiummod.com/wp-content/themes/AT9/_auction/template/img/logo.png" data-sticky-logo="https://at9.premiummod.com/wp-content/themes/AT9/_auction/template/img/logo.png">
            <a href="http://at9.premiummod.com/" title="V9 - AUCTION THEME">
            <img src='https://at9.premiummod.com/wp-content/themes/AT9/_auction/template/img/logo.png' alt='logo' class='img-fluid' />            </a>
         </div>
         <div class="burger-menu">
            <div class="line-menu line-half first-line"></div>
            <div class="line-menu"></div>
            <div class="line-menu line-half last-line"></div>
         </div>
         <nav class="pptv9-menu menu-caret submenu-top-border ">
            <ul id="menu-main-menu" class=""><li  class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://at9.premiummod.com/" class="txt"><span>Home</span></a></li><li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://at9.premiummod.com/how-it-works/" class="txt"><span>How it works</span></a></li><li  class="menu-item menu-item-type-custom menu-item-object-custom"><a href="https://at9.premiummod.com/?s=" class="txt"><span>New</span></a></li><li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://at9.premiummod.com/all-cats/" class="txt"><span>All Cats</span></a></li><li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://at9.premiummod.com/memberships/" class="txt"><span>Memberships</span></a></li><li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://at9.premiummod.com/blog/" class="txt"><span>Blog</span></a></li><li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://at9.premiummod.com/contact/" class="txt"><span>Contact</span></a></li>   
         
                  <li class="menu-item myaccount d-block d-sm-none">
                             <a href="https://at9.premiummod.com/wp-login.php">
                   <span>Sign up/in</span>
                  </a>
                           
         </li>  
                         
		          
		                   
         
         
           
         
         </ul> 
         </nav>
      </div>
   </div>
</div>
</header> <main id="main">
      <div class="container">
        
      <section>
          
         
         
                  
         <div class="modal-dialog" role="document">
   <div class="modal-content">
      <form id="loginform" class="loginform ajax_modal" action="https://at9.premiummod.com/wp-login.php" method="post" >
         <input type="hidden" name="testcookie" value="1" /> 
         <input type="hidden"  name="rememberme" id="rememberme"  value="1" /> 
         <button type="button" class="close modalclose" data-dismiss="modal" aria-label="Close" onclick="jQuery('.modal-backdrop').hide();" style="cursor:pointer;">
         <span aria-hidden="true">&times;</span>
         </button>
         <div class="text-center titleblock">
            <h4 class="title">Members Area</h4>
            <p class="subtitle">Please sign-in to access this page and enjoy the other member benefits.</p>
         </div>
         <div class="line bg-primary">&nbsp;</div>
         <div class="modal-body mt-2">
            <div class="row gap-20">
                              <div class="col-xs-12 col-sm-12 col-md-12">
                  <div class="form-group">
                     <input type="text" class="form-control" name="log" id="user_login" value="" title="Please enter you username"  placeholder=" Username 
                        ">
                     <span class="help-block"></span>
                  </div>
               </div>
               <div class="col-xs-12 col-sm-12 col-md-12">
                  <div class="form-group">
                     <input type="password" class="form-control" name="pwd" id="user_pass" value="" title="Please enter your password" placeholder="Password">
                     <span class="help-block"></span>
                  </div>
               </div>
                              <div class="col-xs-12 col-sm-12 col-md-12">
                  <div class="form-group">		
                     <button type="submit" name="wp-submit" id="wp-submit" class="btn btn-primary btn-block rounded-0 py-3" style="cursor:pointer;">
                     <i class="fa fa-lock" aria-hidden="true"></i>
                     Member Login                     </button>
                  </div>
               </div>
                           </div>
         </div>
      </form>
   </div>
</div>
         
                
          
      </section>
         </div>
     
</main>
<script>
jQuery(document).ready(function(){
jQuery('button.close').hide();
});
</script>

<footer><div class="elementor_footer footerpart footer-top3 py-3 bg-primary ">
<div class="container">
      <div class="row my-4">
      
         <div class="col-md-6 col-lg-4 d-none d-md-block d-lg-block">
            <h6 class="text-uppercase font-weight-bold mb-3">Company Information</h6>
            <div class="text-uppercase mt-5">John Doe Company</div>
            <div>Horse Guards Parade, London, United Kingdom</div>
            <div class="mb-3"></div>
            <div class="socials">
                                <a class="social" target="_blank" href="#" title="Twitter"><i class="fa fa-twitter"></i></a>
                                  
                                   <a class="social" target="_blank" href="#" title="Facebook"><i class="fa fa-facebook"></i></a>
                                    
                                    <a class="social" target="_blank" href="#" title="Google plus"><i class="fa fa-link"></i></a> 
                                    
                                    <a class="social" target="_blank" href="#" title="Dribbble"><i class="fa fa-linkedin"></i></a>
                                    
                                    <a class="social" target="_blank" href="#" title="Skype"><i class="fa fa-skype"></i></a>
                                    
                                    <a class="social" target="_blank" href="#" title="Skype"><i class="fa fa-youtube"></i></a>  
                              </div>
         </div>
         
         
      	<div class="col-md-4 d-none d-lg-block"></div>
      
         
         <div class="col-md-4 d-none d-lg-block">
            <h6 class="text-uppercase font-weight-bold mb-3">Useful Links</h6>
            <div class="row">
               <div class="col-md-6">
                  <ul class="links clearfix mb-0">
                     <li><a href="">My Account</a></li>
                     <li><a href="">Blog</a></li>
                     <li><a href="">About Us</a></li>
                     <li><a href="">Contact</a></li>
                  </ul>
               </div>
               <div class="col-md-6">        
                  <div class="menu-main-menu-container"><ul id="menu-main-menu-1" class="links"><li  class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://at9.premiummod.com/" class="txt"><span>Home</span></a></li><li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://at9.premiummod.com/how-it-works/" class="txt"><span>How it works</span></a></li><li  class="menu-item menu-item-type-custom menu-item-object-custom"><a href="https://at9.premiummod.com/?s=" class="txt"><span>New</span></a></li><li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://at9.premiummod.com/all-cats/" class="txt"><span>All Cats</span></a></li><li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://at9.premiummod.com/memberships/" class="txt"><span>Memberships</span></a></li><li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://at9.premiummod.com/blog/" class="txt"><span>Blog</span></a></li><li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://at9.premiummod.com/contact/" class="txt"><span>Contact</span></a></li></ul></div>     
               </div>
            </div>
         </div>
          
      </div>
</div>
</div><div class="elementor_footer footerpart bg-dark text-light border-top ">
<div class="container py-3">
    
    <div class="row">    
    <div class="col-md-6 text-center text-md-left">
   		<div class="copy mt-2 text-uppercase">&copy; 2020John Doe Company</div>   
    </div>
    <div class="col-md-6 hide-mobile">    
             
          <div class="sicons float-md-right">
                                  <a class="social" target="_blank" href="#"><i class="fa fa-twitter"></i></a>
                                  
                                   <a class="social" target="_blank" href="#"><i class="fa fa-facebook"></i></a>
                                    
                                    <a class="social" target="_blank" href="#"><i class="fa fa-link"></i></a> 
                                    
                                    <a class="social" target="_blank" href="#"><i class="fa fa-linkedin"></i></a>
                                    
                                    <a class="social" target="_blank" href="#"><i class="fa fa-skype"></i></a>
                                    
                                    <a class="social" target="_blank" href="#"><i class="fa fa-youtube"></i></a>  
                              </div>        
    </div>
    </div> 
</div>
</div></footer>
</div><!-- end page -->

<div id="core_footer_ajax"></div>
<!-- Quick View Modal -->
<div id="quickview" class="modal fade" tabindex="-1" role="dialog">
   <div class="modal-dialog">
      <div id="quickview-content"></div>
   </div>
</div>
<!-- end quick view modal -->
<noscript id="deferred-styles">
</noscript>

    <script>
      var loadDeferredStyles = function() {
        var addStylesNode = document.getElementById("deferred-styles");
        var replacement = document.createElement("div");
        replacement.innerHTML = addStylesNode.textContent;
        document.body.appendChild(replacement)
        addStylesNode.parentElement.removeChild(addStylesNode);
      };
      var raf = requestAnimationFrame || mozRequestAnimationFrame ||
          webkitRequestAnimationFrame || msRequestAnimationFrame;
      if (raf) raf(function() { window.setTimeout(loadDeferredStyles, 0); });
      else window.addEventListener('load', loadDeferredStyles);
    </script>
 


<div class="auction_search_timer_layout" style="display:none;"> 
        <di class="box-count-down">
        <span class="countdown-lastest is-countdown">
        <span class="box-count"><span class="number">{dn}</span><span class="text">Days</span></span>
        <span class="dot">:</span>
        <span class="box-count"><span class="number">{hnn}</span> <span class="text">Hrs</span></span>
        <span class="dot">:</span>
        <span class="box-count"><span class="number">{mnn}</span> <span class="text">Mins</span></span>
        <span class="dot">:</span>
        <span class="box-count"><span class="number">{snn}</span> <span class="text">Secs</span></span>
        </span>
        </di>
</div> 


<div id="ajaxLoginModal" class="modal fade login-modal-wrapper" data-width="500" data-backdrop="static" data-keyboard="false" tabindex="-1" style="display: none;"></div>
<div id="ajaxRegisterModal" class="modal fade login-modal-wrapper" data-width="500" data-backdrop="static" data-keyboard="false" tabindex="-1" style="display: none;"></div>
<div id="ajaxSearchModal" class="modal fade search-modal-wrapper" data-width="500" data-backdrop="static" data-keyboard="false" tabindex="-1" style="display: none;"></div>


<div class="auction_search_timer" style="display:none;">
   <di class="box-count-down">
      <span class="countdown-lastest is-countdown">
      <span class="box-count bg-primary"><span class="number">{dn}</span><span class="text">Days</span></span>
      <span class="dot">:</span>
      <span class="box-count bg-primary"><span class="number">{hnn}</span> <span class="text">Hrs</span></span>
      <span class="dot">:</span>
      <span class="box-count bg-primary"><span class="number">{mnn}</span> <span class="text">Mins</span></span>
      <span class="dot">:</span>
      <span class="box-count bg-primary"><span class="number">{snn}</span> <span class="text">Secs</span></span>
      </span>
   </di>
</div>

<script>

jQuery(document).ready(function() {

	jQuery("input.typeahead").typeahead({		 	
		onSelect: function(item) { 
		  window.location = item.extra;
		},
		ajax: {
			url: "http://at9.premiummod.com/?qs=1",
			timeout: 500,
			triggerLength: 1,
			method: "get",
			preDispatch: function (query) { 
				return {
					search: query
				}
			},
			preProcess: function (data) {
			 
				if (data.success === false) {
					// Hide the list, there was some error
					return false;
				}
			 
				return data.mylist;
			}
		},	
	});

	var $modal = jQuery('#ajaxLoginModal');

	jQuery(document).on('click', '.btn-ajax-login' ,function(){
		// create the backdrop and wait for next modal to be triggered
	  
		jQuery('body').modalmanager('loading');

		setTimeout(function(){
			 $modal.load('http://at9.premiummod.com/?core_aj=1&action=loginform', '', function(){
				$modal.modal();
			});
		}, 1000);
	});
	
	var $modal2 = jQuery('#ajaxRegisterModal');

	jQuery(document).on('click', '.btn-ajax-register' ,function(){
		// create the backdrop and wait for next modal to be triggered
	  
		jQuery('body').modalmanager('loading');

		setTimeout(function(){
			 $modal2.load('http://at9.premiummod.com/?core_aj=1&action=registerform', '', function(){
				$modal2.modal();
			});
		}, 1000);
	});
 
	
	var $modal1 = jQuery('#ajaxSearchModal');

	jQuery(document).on('click', '.btn-ajax-search' ,function(){
		// create the backdrop and wait for next modal to be triggered
	  
		jQuery('body').modalmanager('loading');

		setTimeout(function(){
			 $modal1.load('http://at9.premiummod.com/?core_aj=1&action=searchform', '', function(){
				$modal1.modal();
			});
		}, 1000);
 	
		
	}); 

});

</script>

     <script>
	 
	 function ajax_ontick_auction(hours, minutes, seconds, postid){
	 
	  
	  if(hours == 0 && minutes == 0 && seconds > 30 ){
	  //console.log('more than' +minutes + " - " + seconds + ' - ' +postid);
	  
	  jQuery('.itemid'+postid+' .hasCountdown').removeClass('flash-red').addClass('flash-orange').stop().fadeTo('slow', 0.1).fadeTo('slow', 1.0);
	  
	  }else if (hours == 0 && minutes == 0 && seconds > 0 && seconds < 30 ){
	  //console.log('less than' +minutes + " - " + seconds + ' - ' +postid);
	  
	  jQuery('.itemid'+postid+' .hasCountdown').removeClass('flash-orange').addClass('flash-red').stop(true).fadeTo('slow', 0.1).fadeTo('slow', 1.0);
	  
	  }  
	 
	 }
	 
	function ajax_expire_auction(postid) {
		
			jQuery.ajax({
				type: "POST",
				url: 'http://at9.premiummod.com/',
				data: {
					action: "expire_check_listing",
					pid: postid,
				},
				success: function(e) {
				   // alert(e);
				   
				   // REMOVE BLINKING
				   jQuery('.itemid'+postid+' .hasCountdown').stop(true).removeClass('flash-orange').removeClass('flash-red').addClass('flash-grey');				   
				   
				   // ADD IN CUSTOM TEXT
				   jQuery('.itemid'+postid+' .btn-bid').html("ended");
				  
				   // HIDE BUY NOW BOX				   
				   jQuery('.itemid'+postid+' .btn-bid').addClass('btn-ended').removeClass('btn-bid');
			 
				},
				error: function(e) {
					//alert("error" + e)
				}
			})
		}
	</script>

    <script src="https://at9.premiummod.com/wp-content/themes/AT9/framework/js/backup_js/js.bootstrap.js?ver=9.4.0"></script>
<script src="https://at9.premiummod.com/wp-content/themes/AT9/framework/js/backup_js/js.framework.js?ver=9.4.0"></script>
<script src="https://kit.fontawesome.com/5381299f20.js?ver=9.4.0"></script>

 
<script> var ajax_site_url = "http://at9.premiummod.com/"; </script>


</body> 

</html>
